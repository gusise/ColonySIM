package agents;

import java.util.ArrayList;
import java.util.List;

import agents.behaviours.SelfDestruct;
import jade.core.AID;
import jade.core.Agent;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;

public class DF2 extends Agent{

	protected static long SECOND = 1000;
	
	protected void setup() {
		
		addBehaviour( new SelfDestruct(this, 3*SECOND));

		ServiceDescription sd = new ServiceDescription();
		sd.setType( "seller" );
		sd.setName( getLocalName() );
		
		register( sd );
        

	}
	
	protected void takeDown() {
		try {
			DFService.deregister(this);
		} catch (Exception e) {
			// TODO: handle exception
		}
		//System.exit(0);
	}
	
    protected void register( ServiceDescription sd ) 
    {
		DFAgentDescription dfd = new DFAgentDescription();
		dfd.setName( getAID() );
		dfd.addServices(sd);
		
        try {  
			//DFService.deregister(this);
        	DFService.register(this, dfd );  
        }
		catch (FIPAException fe) {
			fe.printStackTrace(); 
		}
    }
}
