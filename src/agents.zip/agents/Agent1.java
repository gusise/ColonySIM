package agents;

import agents.behaviours.Looper;
import jade.core.Agent;

public class Agent1 extends Agent 
{
    protected void setup() 
    {
        addBehaviour( new Looper( this, 300 ) );
        addBehaviour( new Looper( this, 500 ) );
    }
}
