package agents;

import jade.core.Agent;
import jade.core.behaviours.*;


public class Sequence extends Agent 
{
	long      t0 = System.currentTimeMillis();
	// sequence depends on the timestamps and not the order of creation!!!!
	protected void setup() 
	{
		addBehaviour( new WakerBehaviour( this, 250 )
			{
				protected void handleElapsedTimeout() {
					System.out.println( System.currentTimeMillis()-t0 +
						": " + "... Message1");
				}
			});
		
		addBehaviour( new WakerBehaviour( this, 750 )
			{
				protected void handleElapsedTimeout() {
					System.out.println( System.currentTimeMillis()-t0 +
						": " + "  ...and then Message 2");
				}
			});
	}
}
