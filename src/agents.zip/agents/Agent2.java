package agents;

import agents.behaviours.Looper;
import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

public class Agent2 extends Agent {
	
	protected void setup() {
		addBehaviour( new Step1() );
		addBehaviour( new Looper(this, 300));
	}
	
	public class Step1 extends SimpleBehaviour{
		int state = 0;
		
		public void action() {
			if (state==0) block( 200 );
			else if (state==1) {
				System.out.println("-- Message 1 --");
				addBehaviour( new Step2());
			}
			state++;
		}
		
		public boolean done() { return state >1; }
	}
	
	public class Step2 extends SimpleBehaviour{
		int state = 0;
		
		public void action() {
			if (state==0) block( 600 );
			else if (state==1) {
				System.out.println(" - message 2");
				doDelete(); //applies to agent
			}
			state++;
		}
		
		public boolean done() { return state >1; }
	}

}
