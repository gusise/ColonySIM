package agents;

import jade.core.Agent;
import jade.core.behaviours.*;

import jade.core.AID;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

import jade.lang.acl.*;


public class Comm2 extends Agent 
{
	
	String nameAlice = "Alice" ;
	AID alice = new AID( nameAlice, AID.ISLOCALNAME );
	
    String nameFred = "Fred" ;
    AID fred = new AID(nameFred, AID.ISLOCALNAME);
    
    protected void setup() 
    {
    	// create FRED
    	Object [] args = new Object[2];
        args[0] = "3";
        args[1] = "Allo there";
     

        
    	AgentContainer c = getContainerController();
    	try {
    		AgentController a = c.createNewAgent( nameAlice, "agents.Pong", null );
    		AgentController f = c.createNewAgent(nameFred, "agents.ParamAgent", args);
    		a.start();
    		System.out.println("+++ Created: " + alice);
    		f.start();
    		System.out.println("+++ Created:" + fred);
    	}
    	catch (Exception e){}
    	
		addBehaviour(new SimpleBehaviour(this) 
		  {
			 int n = 0;
			 
			 public void action() 
			 {
				ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
				msg.setContent("Message #" + n );
				msg.addReceiver(alice);
				System.out.println("+++ Sending: " + n);
				send(msg);
				block( 1000 );
			 }
			 
			 public  boolean done() {  return ++n > 3;  }
	
		  });
	}
}