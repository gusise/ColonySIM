package agents;

import jade.core.AID;
import jade.core.Agent;
import jade.domain.AMSService;
import jade.domain.FIPAAgentManagement.AMSAgentDescription;
import jade.domain.FIPAAgentManagement.SearchConstraints;

public class AMSDump extends Agent {
	
	protected void setup() {
		AMSAgentDescription [] agents = null;
		
		try {
			SearchConstraints c = new SearchConstraints();
			c.setMaxResults( (long) -1 ); // -1 means return all
			agents = AMSService.search(this, new AMSAgentDescription (), c);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		AID myID = getAID();
		for (int i=0; i<agents.length; i++) {
			AID agentID = agents[i].getName();
            System.out.println(
                    ( agentID.equals( myID ) ? "*** " : "    ")
                    + i + ": " + agentID.getName() 
            );
		}
	}

}
