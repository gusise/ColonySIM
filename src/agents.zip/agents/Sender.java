package agents;

import java.util.ArrayList;
import java.util.List;

import agents.behaviours.ReceiveMessages;
import agents.behaviours.SelfDestruct;
import agents.behaviours.SendPings;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;


public class Sender extends Agent {
	
	protected void setup() {
		List<AID> pingReceivers = new ArrayList<AID>();
		pingReceivers.add(new AID("frank", AID.ISLOCALNAME));
		pingReceivers.add(new AID("joemama", AID.ISLOCALNAME));
		
		
		addBehaviour( new ReceiveMessages(this));
		addBehaviour( new SendPings(this, pingReceivers, 1000));
		addBehaviour(new SelfDestruct(this, 10*1000));
		//remember WakerBehaviour
	}
	
	//Gets called on doDelete()
    protected void takeDown()
    {
    	//This terminates the container
        System.exit(0); 
    }
	
}

