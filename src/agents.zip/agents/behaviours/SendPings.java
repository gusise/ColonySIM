package agents.behaviours;

import java.util.ArrayList;
import java.util.List;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;

/**
 * SendPings( Agent a, List<AID> receiverAgents, long timeout) {@summary Sends
 * given # of PINGs to provided recepients with interval timeout }
 */
public class SendPings extends TickerBehaviour {

	int ping_cnt;
	List<AID> receiverAgents = new ArrayList<AID>();
	long t0 = 0;

	public SendPings(Agent a, List<AID> receiverAgents, long timeout) {
		super(a, timeout);
		this.receiverAgents = receiverAgents;
		this.t0 = System.currentTimeMillis();
	}

	public void onTick() {
		ping_cnt++;
		System.out.println(myAgent.getLocalName() + " <- " + "sending Ping nr." + ping_cnt);

		ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
		msg.setContent("Ping");

		if (!receiverAgents.isEmpty()) {
			receiverAgents.forEach((rcvr) -> msg.addReceiver(rcvr));
			myAgent.send(msg);
			System.out.println("myAgent.getLocalName() <- Time since last ping: " + (System.currentTimeMillis() - t0));
			t0 = System.currentTimeMillis();
		} else {
			System.out.println(myAgent.getLocalName() + " <- " + "failed ping - no receivers");
		}
	}
}
