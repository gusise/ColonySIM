package agents.behaviours;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class ReceiveMessages extends CyclicBehaviour{
	int msg_counter = 0;
	
	public ReceiveMessages(Agent a) {
		super(a);
	}
	public void action() {
		
		//get msg from que
		ACLMessage msg= myAgent.receive();
		
		if (msg!=null) { //handle received msgs
			msg_counter++;								//increment msg cntr
			
			//print msg
			System.out.println( " - " + myAgent.getLocalName() + " <- " 
					+ "received: " + msg.getContent() + " nr." + msg_counter 
					+ " from: " + msg.getSender().getLocalName());
		} 
		block(); //! call at end or suffer from a LOOP
	}
}
