package agents.behaviours;

import jade.core.Agent;
import jade.core.behaviours.WakerBehaviour;

public class SelfDestruct extends WakerBehaviour {

	public SelfDestruct(Agent a, long timeout) {
		super(a, timeout);
	}

	protected void handleElapsedTimeout() {
		System.out.println(myAgent.getLocalName() + " <- Self destructing");
		myAgent.doDelete();
	}

}
