package agents;

import agents.behaviours.Looper;
import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

public class Agent3 extends Agent{
    
	protected void setup(){
		addBehaviour(new TwoSteps());
		addBehaviour(new Looper(this, 1000));
	}
	
	//Gets called on doDelete()
    protected void takeDown()
    {
    	//This terminates the container
        System.exit(0); 
    }
	
	class TwoSteps extends SimpleBehaviour
    {   
        int state = 1;
        
        public void action() 
        {
            switch( state ) {
            case 1:
                System.out.println( " TwoStep Behaviour initialized " );
                block( 200 );
                break;
                
            case 2:
                System.out.println( "--- Message 1 --- " );
                block( 800 );
                break;
            
            case 3:
                System.out.println( "  -- message 2 --" );
                finished = true;
                doDelete();   // applies to the Agent
            }
            state++;
        }
        
        private boolean finished = false;
        public  boolean done() {  return finished;  }
    }

}
